"""My first program for COMP110."""

__author__ = "730617864"

print("Hello, world.")
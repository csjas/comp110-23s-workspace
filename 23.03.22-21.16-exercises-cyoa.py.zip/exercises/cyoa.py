"""Choose Your Own Adventure."""

__author__ = "730617864"

import random

score = 0
Asking_players_name = ""

# greeting procedure
def greet():
    global Asking_players_name
    print("Welcome to the Coinflip guessing game!")
    Asking_players_name = input("What's your name?\n")

# coinflip function
def coinflip(players_guess):
    global score
    player_flips_coin = random.choice(['heads', 'tails'])
    print(f"The coin lands on {player_flips_coin}!")
    if players_guess == player_flips_coin:
        score += 1
        print(f"Congratulations, {Asking_players_name}! Your guess was correct and you have scored 1 point.")
    else:
        print(f"Sorry, {Asking_players_name}, better luck next time!")
    return score

# main function
def main():
    global Asking_players_name
    global score
    greet()
    print(f"Hello, {Asking_players_name}! Let's play the coinflip guessing game.")
    while True:
        print(f"Your current score is {score}.")
        player_guess = input("Enter your guess (heads or tails) or type 'quit' to end the game.\n")
        if player_guess.lower() == "quit":
            print(f"Thank you for playing the game, {Asking_players_name}! Your score is {score}.")
            break
        elif player_guess.lower() not in ['heads', 'tails']:
            print("Invalid option, please enter either 'heads' or 'tails'.")
        else:
            coinflip(player_guess.lower())

if __name__ == "__main__":
    main()

"""EX04 - 'List' Utils Function. """

__author__ = "730617864"

def all(list1: list[int], parameter: int) -> bool:
    idx = 0
    while idx < len(list1):
        if list1[idx] != parameter:
            return False
        idx += 1
    return True


def max(list1: list[int]) -> int:
    if not list1:
        raise ValueError("max() arg is an empty List")
    largestnumber = list1[0]
    idx = 1
    while idx < len(list1):
        if list1[idx] > largestnumber:
            largestnumber = list1[idx]
        idx += 1
    return largestnumber


def is_equal(firstnumber: list[int], secnumber: list[int]) -> bool:
    i = 0
    while i < len(firstnumber) and i < len(secnumber):
        if firstnumber[i] != secnumber[i]:
            return False
        i += 1
    return len(firstnumber) == len(secnumber)

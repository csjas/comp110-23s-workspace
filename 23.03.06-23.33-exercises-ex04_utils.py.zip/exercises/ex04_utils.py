"""EX04 - 'List' Utility Functions."""

__author___ = "730617864"


def all(list1: list[int], parameter: int) -> bool:
    for numbers in list1:
        if numbers != parameter:
            return False
    return True


def max(list1: list[int]) -> int:
    if len(input) == 0:
        raise ValueError("max() arg is an empty List")
    largestnumber = list1[0]
    for numbers in list1:
        if numbers > largestnumber:
            largestnumber = numbers
    return largestnumber


def is_equal(firstnumber: list[int], secnumber: list[int]) -> bool:
    if len(firstnumber) != len(secnumber):
        return False
    for idx in range(len(firstnumber)):
        if firstnumber[idx] != secnumber[idx]:
            return False
    return True
